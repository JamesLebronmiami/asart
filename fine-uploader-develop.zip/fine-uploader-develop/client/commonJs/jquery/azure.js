"use strict";

module.exports = require("../../azure.jquery.fine-uploader/azure.jquery.fine-uploader");
