"use strict";

module.exports = require("../azure.fine-uploader/azure.fine-uploader");
