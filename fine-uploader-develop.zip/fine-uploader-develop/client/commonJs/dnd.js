"use strict";

module.exports = require("../dnd/dnd");
