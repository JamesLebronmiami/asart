/*global qq */
qq.version = "5.15.0";
